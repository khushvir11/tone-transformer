"""
Real-time async generation engine.

Implements the "Asynchronous Waiter" pattern from the brief: instead of
blocking on one API call at a time, we fire many requests concurrently and
let asyncio overlap their network-wait time. A semaphore caps concurrency so
we don't trip provider rate limits (HTTP 429), and tenacity-style exponential
backoff with jitter recovers from transient failures.
"""

from __future__ import annotations

import asyncio
import json
import os
import random
from typing import List, Optional

from .config import (
    MAX_CONCURRENT_REQUESTS,
    RETRY_BASE_DELAY_SECONDS,
    RETRY_MAX_ATTEMPTS,
    resolve_generation_params,
)
from .models import CopyOutput, GenerationRequest
from .templates import compile_prompt


class GenerationError(RuntimeError):
    pass


async def _call_model_with_retry(client, request: GenerationRequest, prompt: str) -> CopyOutput:
    """Single request, wrapped in manual exponential backoff + jitter.

    (Hand-rolled here instead of importing `tenacity` so the engine has zero
    hard dependency beyond the API client itself — swap in @tenacity.retry
    if you'd rather declare this via decorator.)
    """
    params = resolve_generation_params(request.model, request.temperature, request.top_p)
    last_error: Optional[Exception] = None

    for attempt in range(1, RETRY_MAX_ATTEMPTS + 1):
        try:
            kwargs = {
                "model": params.model,
                "messages": [
                    {"role": "system", "content": "You output only valid JSON matching the given schema."},
                    {"role": "user", "content": prompt},
                ],
                "temperature": params.temperature,
                "top_p": params.top_p,
                params.token_param_name: params.token_param_value,
                "response_format": {"type": "json_object"},
            }
            response = await client.chat.completions.create(**kwargs)
            raw = response.choices[0].message.content
            data = json.loads(raw)
            data.setdefault("platform", request.platform.value)
            data.setdefault("char_count", len(data.get("headline", "")) + len(data.get("body", "")))
            return CopyOutput.model_validate(data)

        except Exception as exc:  # noqa: BLE001 - broad on purpose, we retry any transient failure
            last_error = exc
            if attempt == RETRY_MAX_ATTEMPTS:
                break
            delay = RETRY_BASE_DELAY_SECONDS * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            await asyncio.sleep(delay)

    raise GenerationError(f"Failed after {RETRY_MAX_ATTEMPTS} attempts: {last_error}")


async def generate_one(client, semaphore: asyncio.Semaphore, request: GenerationRequest) -> CopyOutput:
    prompt = compile_prompt(
        product_name=request.product_name,
        product_description=request.product_description,
        platform=request.platform,
        tone=request.tone,
    )
    async with semaphore:
        result = await _call_model_with_retry(client, request, prompt)

    check = result.compliance_check()
    if not check.passed:
        raise GenerationError(f"Compliance check failed: {'; '.join(check.errors)}")
    return result


async def generate_batch_realtime(
    client, requests: List[GenerationRequest], max_concurrency: int = MAX_CONCURRENT_REQUESTS
) -> List[CopyOutput]:
    """Fan out N requests concurrently, gated by a semaphore.

    Uses asyncio.gather (guaranteed input-order output) since callers
    generally want results.zip(requests) to line up — see the Concurrency
    Patterns Comparison in the brief for when as_completed would be the
    better fit (streaming UI instead of a batch report).
    """
    semaphore = asyncio.Semaphore(max_concurrency)
    tasks = [generate_one(client, semaphore, r) for r in requests]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    output: List[CopyOutput] = []
    for req, res in zip(requests, results):
        if isinstance(res, Exception):
            raise GenerationError(
                f"Generation failed for product='{req.product_name}' "
                f"platform='{req.platform.value}': {res}"
            )
        output.append(res)
    return output


def build_client():
    """Construct an AsyncOpenAI client from the OPENAI_API_KEY env var.

    Kept as a thin factory so tests/CI can monkeypatch this without touching
    engine internals.
    """
    from openai import AsyncOpenAI  # imported lazily so the module loads without the dep installed

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise GenerationError(
            "OPENAI_API_KEY is not set. Export it before running, e.g.\n"
            "  export OPENAI_API_KEY=sk-...\n"
            "Or use --mock to run the pipeline without hitting a real API."
        )
    return AsyncOpenAI(api_key=api_key)
