"""
Bulk processing pipeline.

For jobs that don't need real-time UI streaming, the brief mandates routing
through the OpenAI Batch API: 50% lower token cost, a separate/larger rate
limit pool, in exchange for a 24-hour completion window. This module builds
the JSONL batch file and submits it, with an optional `openbatch`-style
higher-level client if that package is installed (it wraps the raw
file-upload/poll/download dance behind a `.responses.create()` call).

Usage pattern:
    python -m src.batch requests.csv --out batch_results.jsonl
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import List

from .config import resolve_generation_params
from .models import GenerationRequest, Platform, Tone
from .templates import compile_prompt


def requests_from_csv(path: str) -> List[GenerationRequest]:
    """CSV columns expected: product_name, product_description, platform, tone[, model]"""
    reqs = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            reqs.append(
                GenerationRequest(
                    product_name=row["product_name"],
                    product_description=row["product_description"],
                    platform=Platform(row["platform"].strip().lower()),
                    tone=Tone(row["tone"].strip().lower()),
                    model=row.get("model", "gpt-4o") or "gpt-4o",
                )
            )
    return reqs


def build_batch_jsonl(requests: List[GenerationRequest], out_path: str) -> str:
    """Write the raw JSONL body the OpenAI Batch API expects, one line per request.

    This is the "before" path in the brief's openbatch diagram — kept here as
    the portable fallback that needs zero extra dependencies.
    """
    lines = []
    for i, req in enumerate(requests):
        prompt = compile_prompt(
            product_name=req.product_name,
            product_description=req.product_description,
            platform=req.platform,
            tone=req.tone,
        )
        params = resolve_generation_params(req.model, req.temperature, req.top_p)
        body = {
            "model": params.model,
            "messages": [
                {"role": "system", "content": "You output only valid JSON matching the given schema."},
                {"role": "user", "content": prompt},
            ],
            "temperature": params.temperature,
            "top_p": params.top_p,
            params.token_param_name: params.token_param_value,
            "response_format": {"type": "json_object"},
        }
        lines.append(json.dumps({
            "custom_id": f"req-{i}-{req.platform.value}",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": body,
        }))

    Path(out_path).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_path


def submit_via_raw_api(jsonl_path: str):
    """Submit using the plain openai SDK: upload file -> create batch."""
    from openai import OpenAI

    client = OpenAI()
    uploaded = client.files.create(file=open(jsonl_path, "rb"), purpose="batch")
    batch = client.batches.create(
        input_file_id=uploaded.id,
        endpoint="/v1/chat/completions",
        completion_window="24h",
    )
    print(f"Batch submitted: {batch.id} (status: {batch.status})")
    print("Poll with: client.batches.retrieve(batch_id) until status == 'completed'")
    return batch


def submit_via_openbatch(requests: List[GenerationRequest]):
    """Submit using the `openbatch` convenience wrapper, if installed.

    Mirrors the standard client (`collector.responses.create(...)`) and
    integrates natively with Pydantic output schemas, per the brief.
    """
    try:
        from openbatch import BatchCollector  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "openbatch is not installed. `pip install openbatch --break-system-packages`, "
            "or use submit_via_raw_api() / build_batch_jsonl() instead."
        ) from exc

    from .models import CopyOutput

    collector = BatchCollector()
    for req in requests:
        prompt = compile_prompt(
            product_name=req.product_name,
            product_description=req.product_description,
            platform=req.platform,
            tone=req.tone,
        )
        collector.responses.create(
            model=req.model,
            input=prompt,
            text_format=CopyOutput,
            temperature=req.temperature,
            top_p=req.top_p,
        )
    return collector.run()


def main():
    parser = argparse.ArgumentParser(description="Bulk copy generation via the OpenAI Batch API")
    parser.add_argument("csv_path", help="CSV with columns: product_name,product_description,platform,tone")
    parser.add_argument("--out", default="batch_input.jsonl", help="Where to write the JSONL batch file")
    parser.add_argument("--submit", action="store_true", help="Also submit the batch to OpenAI")
    args = parser.parse_args()

    requests = requests_from_csv(args.csv_path)
    path = build_batch_jsonl(requests, args.out)
    print(f"Wrote {len(requests)} requests to {path}")

    if args.submit:
        submit_via_raw_api(path)


if __name__ == "__main__":
    main()
