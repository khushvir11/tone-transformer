"""
Structured output schemas for the Automated Copywriting & Tone Transformer.

These models are passed as `text_format=` (or via a JSON-schema tool call,
depending on which client wrapper you use) so the model's response is
validated the moment it comes back — no fragile regex-parsing of free text.
"""

from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class Platform(str, Enum):
    LINKEDIN = "linkedin"
    INSTAGRAM = "instagram"
    EMAIL = "email"
    TWITTER = "twitter"  # X, 280-char hard limit


class Tone(str, Enum):
    PROFESSIONAL = "professional"
    WITTY = "witty"
    URGENT = "urgent"
    FRIENDLY = "friendly"
    LUXURY = "luxury"
    BOLD = "bold"


# Per-platform hard constraints enforced at both prompt-compile time and
# validation time. This is the "gatekeeper" layer described in the brief:
# raw model output never reaches the user without a compliance check.
PLATFORM_LIMITS = {
    Platform.LINKEDIN: {"max_chars": 3000, "needs_hashtags": True, "max_hashtags": 5},
    Platform.INSTAGRAM: {"max_chars": 2200, "needs_hashtags": True, "max_hashtags": 15},
    Platform.EMAIL: {"max_chars": 5000, "needs_hashtags": False, "max_hashtags": 0},
    Platform.TWITTER: {"max_chars": 280, "needs_hashtags": True, "max_hashtags": 3},
}


class CopyOutput(BaseModel):
    """The strict schema every generation must conform to."""

    platform: Platform
    headline: str = Field(..., description="Hook / subject line / first line")
    body: str = Field(..., description="Main copy body")
    hashtags: List[str] = Field(default_factory=list)
    cta: str = Field(..., description="Call to action, e.g. 'Shop now'")
    char_count: int = Field(..., description="Character count of headline+body combined")

    @field_validator("hashtags")
    @classmethod
    def strip_hash_symbol_duplicates(cls, v: List[str]) -> List[str]:
        return [h.lstrip("#").strip() for h in v if h.strip()]

    def compliance_check(self) -> "ComplianceResult":
        limits = PLATFORM_LIMITS[self.platform]
        total_len = len(self.headline) + len(self.body)
        errors = []
        if total_len > limits["max_chars"]:
            errors.append(
                f"Length {total_len} exceeds {self.platform.value} limit of {limits['max_chars']}"
            )
        if limits["needs_hashtags"] and not self.hashtags:
            errors.append(f"{self.platform.value} requires at least one hashtag")
        if len(self.hashtags) > limits["max_hashtags"]:
            errors.append(
                f"{len(self.hashtags)} hashtags exceeds {self.platform.value} max of {limits['max_hashtags']}"
            )
        return ComplianceResult(passed=not errors, errors=errors)


class ComplianceResult(BaseModel):
    passed: bool
    errors: List[str] = Field(default_factory=list)


class GenerationRequest(BaseModel):
    """One row of work — CLI args or a CSV row both normalize into this."""

    product_name: str
    product_description: str
    platform: Platform
    tone: Tone
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    top_p: float = Field(0.9, ge=0.0, le=1.0)
    model: str = "gpt-4o"

    @field_validator("product_name", "product_description")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("must not be empty")
        return v.strip()
