"""
Dynamic prompt template compilation.

Design principle from the brief: "the application layer is the gatekeeper."
The end user (or CSV row) supplies raw facts only — Product_Name, a
description, Platform, Tone. This module owns the hidden master template and
is the ONLY place allowed to shape the actual instruction sent to the model.
Nothing downstream should be hand-assembling prompt strings.
"""

from __future__ import annotations

from .models import Platform, Tone, PLATFORM_LIMITS

# The locked "brand voice" preamble. In a real deployment this would live in
# a config file / secrets store, not be editable per-request.
_MASTER_INSTRUCTION = """You are an expert marketing copywriter working for a brand that values \
clarity and honesty in advertising. You never invent statistics, awards, or \
claims that were not provided to you.

TASK
Write platform-native marketing copy for the following product.

Product name: {product_name}
Product description: {product_description}
Target platform: {platform_label}
Requested tone: {tone_label}

PLATFORM CONSTRAINTS (must be followed exactly)
{platform_constraints}

TONE GUIDANCE
{tone_guidance}

OUTPUT FORMAT
Return a headline, a body, a call-to-action, and (if required by the platform) \
a list of relevant hashtags. Do not include the character count instructions \
in the output itself — that is computed separately."""


_TONE_GUIDANCE = {
    Tone.PROFESSIONAL: "Formal register, no slang, confident and precise claims only.",
    Tone.WITTY: "Playful wordplay and unexpected hooks are welcome; keep it tasteful, not cringe.",
    Tone.URGENT: "Convey scarcity or time-sensitivity without sounding like spam or using ALL CAPS.",
    Tone.FRIENDLY: "Warm, conversational, second person ('you'), like a helpful friend.",
    Tone.LUXURY: "Restrained, elegant language. Show don't tell. Avoid exclamation points.",
    Tone.BOLD: "Short punchy sentences, strong verbs, confident declarative statements.",
}

_PLATFORM_LABELS = {
    Platform.LINKEDIN: "LinkedIn (B2B / professional feed post)",
    Platform.INSTAGRAM: "Instagram (visual-first caption)",
    Platform.EMAIL: "Marketing email (subject + body)",
    Platform.TWITTER: "X / Twitter (single post)",
}


def _platform_constraints_block(platform: Platform) -> str:
    limits = PLATFORM_LIMITS[platform]
    lines = [f"- Maximum {limits['max_chars']} characters for headline + body combined."]
    if limits["needs_hashtags"]:
        lines.append(
            f"- Include between 1 and {limits['max_hashtags']} relevant hashtags."
        )
    else:
        lines.append("- Do not include hashtags.")
    if platform == Platform.TWITTER:
        lines.append("- This is a hard limit. Do not truncate mid-sentence; write to fit.")
    if platform == Platform.EMAIL:
        lines.append("- The headline field should be used as the email subject line.")
    return "\n".join(lines)


def compile_prompt(
    product_name: str,
    product_description: str,
    platform: Platform,
    tone: Tone,
) -> str:
    """Merge raw variables into the hidden master template.

    This is the 'Dynamic Compilation' step from the brief: we use Python
    f-strings (via .format here, for the same effect) to inject user
    variables into a template the user never sees directly.
    """
    return _MASTER_INSTRUCTION.format(
        product_name=product_name,
        product_description=product_description,
        platform_label=_PLATFORM_LABELS[platform],
        tone_label=tone.value,
        platform_constraints=_platform_constraints_block(platform),
        tone_guidance=_TONE_GUIDANCE[tone],
    )
