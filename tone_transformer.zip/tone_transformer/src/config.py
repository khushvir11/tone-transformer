"""
System-parameter routing.

Per the "Token Limit Decision Tree" in the brief: legacy chat models take
`max_tokens`; newer reasoning models take `max_completion_tokens` and will
error if you pass the legacy param. This module is the single place that
decides which key to use so call sites never have to know the difference.
"""

from __future__ import annotations

from dataclasses import dataclass

# Models that use internal chain-of-thought and therefore need the newer
# completion-token parameter name, plus more headroom.
REASONING_MODELS = {"o1", "o1-mini", "o3", "o3-mini", "gpt-4o", "gpt-4o-mini"}

LEGACY_MODELS = {"gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"}


@dataclass(frozen=True)
class GenerationParams:
    model: str
    temperature: float
    top_p: float
    token_param_name: str
    token_param_value: int


def resolve_generation_params(
    model: str, temperature: float, top_p: float
) -> GenerationParams:
    """Pick the correct token-limit parameter name/value for the given model."""
    if model in REASONING_MODELS:
        return GenerationParams(
            model=model,
            temperature=temperature,
            top_p=top_p,
            token_param_name="max_completion_tokens",
            token_param_value=300,  # 150-300 range per brief; headroom for CoT
        )
    # Default to legacy behavior for anything unrecognized — fail safe with
    # the more widely-supported parameter name rather than guessing.
    return GenerationParams(
        model=model,
        temperature=temperature,
        top_p=top_p,
        token_param_name="max_tokens",
        token_param_value=500,  # 50-500 range per brief, with truncation buffer
    )


# Concurrency + retry defaults for the async engine.
MAX_CONCURRENT_REQUESTS = 10
RETRY_MAX_ATTEMPTS = 5
RETRY_BASE_DELAY_SECONDS = 1.0
