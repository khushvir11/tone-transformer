"""
CLI entry point: argparse captures product/tone/platform variables and
generation parameters, then routes into either the real-time async engine
or (via src/batch.py) the bulk pipeline.

Examples:
    python run.py --product "Aurora Desk Lamp" \\
        --description "A dimmable LED desk lamp with wireless charging base." \\
        --platform linkedin instagram email \\
        --tone witty --temperature 0.8 --top-p 0.9

    python run.py --product "..." --description "..." --platform twitter \\
        --tone bold --mock          # no API key required, uses the mock client
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .config import MAX_CONCURRENT_REQUESTS
from .engine import GenerationError, build_client, generate_batch_realtime
from .models import GenerationRequest, Platform, Tone


def platform_type(value: str) -> Platform:
    try:
        return Platform(value.strip().lower())
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"invalid platform '{value}', choose from {[p.value for p in Platform]}"
        ) from exc


def tone_type(value: str) -> Tone:
    try:
        return Tone(value.strip().lower())
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"invalid tone '{value}', choose from {[t.value for t in Tone]}"
        ) from exc


def build_parser() -> argparse.ArgumentParser:
    # prefix_chars kept at the default '-' for portability; the brief's '+a'
    # example is for distinguishing custom actions from standard flags in
    # more exotic CLIs, noted here for reference but not needed for this tool.
    parser = argparse.ArgumentParser(
        prog="tone-transformer",
        description="Generate platform-tailored, tone-controlled marketing copy.",
    )
    parser.add_argument("--product", required=True, help="Product_Name")
    parser.add_argument("--description", required=True, help="Raw product description")
    parser.add_argument(
        "--platform", nargs="+", type=platform_type, required=True,
        help=f"One or more of: {[p.value for p in Platform]}",
    )
    parser.add_argument("--tone", type=tone_type, required=True, help=f"One of: {[t.value for t in Tone]}")
    parser.add_argument("--model", default="gpt-4o", help="Model name (routes token param automatically)")
    parser.add_argument("--temperature", type=float, default=0.7, help="0.0 (deterministic) - 2.0 (max variance)")
    parser.add_argument("--top-p", type=float, default=0.9, dest="top_p")
    parser.add_argument("--concurrency", type=int, default=MAX_CONCURRENT_REQUESTS)
    parser.add_argument("--mock", action="store_true", help="Use the offline mock client instead of a real API")
    parser.add_argument("--out", help="Write JSON results to this file instead of stdout")
    return parser


async def _run(args: argparse.Namespace) -> list:
    requests = [
        GenerationRequest(
            product_name=args.product,
            product_description=args.description,
            platform=platform,
            tone=args.tone,
            temperature=args.temperature,
            top_p=args.top_p,
            model=args.model,
        )
        for platform in args.platform
    ]

    if args.mock:
        from .mock_client import MockAsyncOpenAI
        client = MockAsyncOpenAI()
    else:
        client = build_client()

    results = await generate_batch_realtime(client, requests, max_concurrency=args.concurrency)
    return [r.model_dump() for r in results]


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        results = asyncio.run(_run(args))
    except GenerationError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    output = json.dumps(results, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"Wrote {len(results)} result(s) to {args.out}")
    else:
        print(output)
    return 0


if __name__ == "__main__":
    sys.exit(main())
