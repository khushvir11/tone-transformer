#!/usr/bin/env python3
"""Thin wrapper so `python run.py ...` works from the project root."""
import sys

from src.cli import main

if __name__ == "__main__":
    sys.exit(main())
